package finalvariable;

public class AreaMainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AreaOfCircle a=new AreaOfCircle();
		a.setR(2.1);
		System.out.println("Area Of Circle = "+a.AreaCircle());
	}

}
