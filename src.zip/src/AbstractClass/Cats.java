package AbstractClass;

public class Cats extends Animal {
	public void cat() {System.out.println("Cats meow");}
public void dog() {}

}
