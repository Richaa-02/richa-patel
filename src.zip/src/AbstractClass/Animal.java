package AbstractClass;

abstract public class Animal {
	abstract void cat();
	abstract void dog();

}
