package AbstractClass;

public class Dogs extends Animal {
	public void cat() {}
	public void dog() {System.out.println("Dogs Bark");}

}
