package inheritance_exercise;

public class Square extends Rectangle{
	
	public int AreaOfSquare() {
		return getL()*getL();
	}

	

}
