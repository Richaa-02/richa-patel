package workshop_java;

public class Area {
	private double l,b;

	public void setDim(double l,double b) {
		this.l = l;
		this.b=b;
	}

	public double getDim() {
		return l*b;
	}
	
	

}
