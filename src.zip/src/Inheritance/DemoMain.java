package Inheritance;

public class DemoMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ChildClass c=new ChildClass();
		c.setAmt(1000);
		System.out.println(c);
	}

}
