package Inheritance;

public class ChildClass extends BaseClass{

}
