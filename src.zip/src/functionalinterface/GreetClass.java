package functionalinterface;

public class GreetClass implements GreetInterface{
	public void SayHello() {System.out.println("Hello ! Good Morning");
	}
}
