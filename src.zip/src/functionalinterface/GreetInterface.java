package functionalinterface;

@FunctionalInterface
public interface GreetInterface {
	public void SayHello();

}

